﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

    //Rigidbody variable to capture the same-named component from Player sphere object in unity
    public float speed;
    private Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();

    }

    //Fixed update used applying forces
    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");

        //y is zero since ball isn't moving up off the plane
        Vector3 movement = new Vector3(moveHorizontal, 0.0f, 0.0f);

        //apply a force to sphere based on received Input
        rb.AddForce(movement * speed);
    }
}
