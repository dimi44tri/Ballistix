﻿using UnityEngine;
using System.Collections;

public class DestroyByBoundary : MonoBehaviour
{

    void OnTriggerExit(Collider other)
    {
        // Destroy everything that leaves the boudary trigger
        Destroy(other.gameObject);
    }

}
